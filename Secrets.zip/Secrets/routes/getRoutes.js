const express=require('express');
const router=require('express').Router()
const getController=require('../controller/getController')


  
  router.get("/", function(req, res){
    res.render("home");
  });

 router.get("/login", function(req, res){
    res.render("login");
  });
  
  router.get("/register", function(req, res){
    res.render("register");
  });

  router.get("/submit",getController.submit);


//   logout
router.get("/logout", getController.logout);

module.exports=router;