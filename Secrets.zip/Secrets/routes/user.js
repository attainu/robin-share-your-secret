  const router=require('express').Router()

  const passport = require("passport");
  const userController=require('../controller/userController')

  app.post("/register",userController.register);
  
  app.post("/login", userController.login)

  app.post("/submit",userController.submit);

  app.get("/secrets", function(req, res){
    User.find({"secret": {$ne: null}}, function(err, foundUsers){
      if (err){
        console.log(err);
      } else {
        if (foundUsers) {
          res.render("secrets", {usersWithSecrets: foundUsers});
        }
      }
    });
  });