module.exports={
    googleKey:{
        CLIENT_ID:"560768197808-mur1p64ibglu85dndtbrf7qhdioa82i6.apps.googleusercontent.com",
        
        CLIENT_SECRET:"7OOLrGhqBgWoO1XBVBXhGO8q"
    }
}