const passport=require('passport');
const express=require('express')

getController={}

getController.submit =  function(req, res){
    if (req.isAuthenticated()){
      res.render("submit");
    } else {
      res.redirect("/login");
    }
  }

  getController.logout=function(req, res){
    req.logout();
    res.redirect("/")};


    module.exports=getController;