
const passport = require("passport");
const GoogleStrategy = require('passport-google-oauth20').Strategy;
const findOrCreate = require('mongoose-findorcreate');
const User=require('../model/user')
const keys=require('../config/key')

const gooleStrategy=new GoogleStrategy({
    clientID: keys.googleKey.CLIENT_ID, 
    clientSecret: keys.googleKey.CLIENT_SECRET,
    callbackURL: "http://localhost:3000/auth/google/secrets",
    userProfileURL: "https://www.googleapis.com/oauth2/v3/userinfo"
  },
  function(accessToken, refreshToken, profile, cb) {
    console.log(profile);

    User.findOrCreate({ googleId: profile.id ,name:profile.displayName}, function (err, user) {
      return cb(err, user);
    });
  }
);

passport.use(User.createStrategy());

passport.serializeUser(function(user, done) {
  done(null, user.id);
});

passport.deserializeUser(function(id, done) {
  User.findById(id, function(err, user) {
    done(err, user);
  });
});

module.exports=GoogleStrategy;